#include "button.h"
#include <iostream>

void handleWelcomeScreenEvents(SDL_Event& event, bool& showWelcomeScreen, bool& showLoadingScreen,
                               bool& showDirection, int& currentPage) {
    if (event.type == SDL_MOUSEBUTTONDOWN) {
        int mouseX = event.button.x;
        int mouseY = event.button.y;
        SDL_Point mousePoint = {mouseX, mouseY};

        if (SDL_PointInRect(&mousePoint, &playButton)) {
            showWelcomeScreen = false;
            showLoadingScreen = true;
        }
        if (!showDirection && SDL_PointInRect(&mousePoint, &directionButton)) {
            showDirection = true;
            currentPage = 1;
        }
        if (showDirection) {
            if (SDL_PointInRect(&mousePoint, &nextRect) && currentPage == 1) currentPage = 2;
            if (SDL_PointInRect(&mousePoint, &backRect) && currentPage == 2) currentPage = 1;
            if (SDL_PointInRect(&mousePoint, &closeRect)) showDirection = false;
        }
    }
}

void chooseLevel(SDL_Renderer* renderer, SDL_Texture* levelPreviewTexture, bool& showLevelPreview, int& level,
                 SDL_Rect& level1Button, SDL_Rect& level2Button, SDL_Rect& level3Button, SDL_Rect& level4Button,
                 SDL_Event& event, bool& loaded, Uint32& levelStartTime, int& lives, int& seeds, int& plantedFlower,
                 int& beeCount, std::vector<Bee>& bees, std::vector<Plant>& plants, TTF_Font* font) {
    SDL_RenderCopy(renderer, levelPreviewTexture, nullptr, nullptr);

    SDL_Rect starRect = {0, 0, 40, 40};
    if (completedLevels[0]) {
        starRect.x = level1Button.x + level1Button.w - 40;
        starRect.y = level1Button.y;
        SDL_RenderCopy(renderer, star, nullptr, &starRect);
    }
    if (completedLevels[1]) {
        starRect.x = level2Button.x + level2Button.w - 40;
        starRect.y = level2Button.y;
        SDL_RenderCopy(renderer, star, nullptr, &starRect);
    }
    if (completedLevels[2]) {
        starRect.x = level3Button.x + level3Button.w - 40;
        starRect.y = level3Button.y;
        SDL_RenderCopy(renderer, star, nullptr, &starRect);
    }
    if (completedLevels[3]) {
        starRect.x = level4Button.x + level4Button.w - 40;
        starRect.y = level4Button.y;
        SDL_RenderCopy(renderer, star, nullptr, &starRect);
    }

    SDL_Color white = {255, 255, 255, 255};
    char textBuffer[100];
    sprintf(textBuffer, "Last Run - Flowers: %d, Seeds: %d", lastPlantedFlower, lastSeeds);
    SDL_Surface* statsSurface = TTF_RenderText_Solid(font, textBuffer, white);
    SDL_Texture* statsTexture = SDL_CreateTextureFromSurface(renderer, statsSurface);
    SDL_Rect statsRect = {10, 10, statsSurface->w, statsSurface->h};
    SDL_RenderCopy(renderer, statsTexture, nullptr, &statsRect);

    SDL_FreeSurface(statsSurface);
    SDL_DestroyTexture(statsTexture);

    if (event.type == SDL_MOUSEBUTTONDOWN) {
        int mouseX = event.button.x;
        int mouseY = event.button.y;
        SDL_Point mousePoint = {mouseX, mouseY};

        if (SDL_PointInRect(&mousePoint, &level1Button)) {
            level = 1;
            lives = 5;
            seeds = 10;
            plantedFlower = 0;
            beeCount = 0;
            bees.clear();
            plants.clear();
            showLevelPreview = false;
            loaded = true;
            levelStartTime = 0;
        }
        else if (SDL_PointInRect(&mousePoint, &level2Button)) {
            level = 2;
            lives = 5;
            seeds = 10;
            plantedFlower = 0;
            beeCount = 1;
            bees.clear();
            plants.clear();
            for (int i = 0; i < 1; i++) {
                Bee newBee;
                newBee.rect = {rand() % 800, rand() % 600, BEE_WIDTH, BEE_HEIGHT};
                newBee.moveTime = SDL_GetTicks();
                newBee.velocityX = (rand() % (2 * BEE_SPEED)) - BEE_SPEED;
                newBee.velocityY = (rand() % (2 * BEE_SPEED)) - BEE_SPEED;
                bees.push_back(newBee);
            }
            showLevelPreview = false;
            loaded = true;
            levelStartTime = 0;
        }
        else if (SDL_PointInRect(&mousePoint, &level3Button)) {
            level = 3;
            lives = 4;
            seeds = 8;
            plantedFlower = 0;
            beeCount = 2;
            bees.clear();
            plants.clear();
            for (int i = 0; i < 2; i++) {
                Bee newBee;
                newBee.rect = {rand() % 800, rand() % 600, BEE_WIDTH, BEE_HEIGHT};
                newBee.moveTime = SDL_GetTicks();
                newBee.velocityX = (rand() % (2 * BEE_SPEED)) - BEE_SPEED;
                newBee.velocityY = (rand() % (2 * BEE_SPEED)) - BEE_SPEED;
                bees.push_back(newBee);
            }
            showLevelPreview = false;
            loaded = true;
            levelStartTime = 0;
        }
        else if (SDL_PointInRect(&mousePoint, &level4Button)) {
            level = 4;
            lives = 4;
            seeds = 8;
            plantedFlower = 0;
            beeCount = 3;
            bees.clear();
            plants.clear();
            for (int i = 0; i < 3; i++) {
                Bee newBee;
                newBee.rect = {rand() % 800, rand() % 600, BEE_WIDTH, BEE_HEIGHT};
                newBee.moveTime = SDL_GetTicks();
                newBee.velocityX = (rand() % (2 * BEE_SPEED)) - BEE_SPEED;
                newBee.velocityY = (rand() % (2 * BEE_SPEED)) - BEE_SPEED;
                bees.push_back(newBee);
            }
            showLevelPreview = false;
            loaded = true;
            levelStartTime = 0;
        }
    }
}

void handleGameEvents(SDL_Event& event, bool& showDirection, int& currentPage, bool& facingLeft,
                      SDL_Rect& playerRect, int& seeds, int& plantedFlower, bool& isPaused, bool& running,
                      bool& showPassScreen, bool& showLevelPreview, bool& loaded, int& level, int& lives,
                      bool& showGameOverScreen) {
    static bool inContactWithBee = false;
    static Uint32 dizzyStartTime = 0;

    if (event.type == SDL_KEYDOWN && !showDirection && !isPaused && !showPassScreen && !showGameOverScreen) {
        if (event.key.keysym.sym == SDLK_SPACE)
            dropSeed(playerRect, seeds, plantedFlower);
        if (event.key.keysym.sym == SDLK_RETURN)
            pickFlower(playerRect, seeds, plantedFlower);
        if (event.key.keysym.sym == SDLK_LEFT)
            facingLeft = true;
        if (event.key.keysym.sym == SDLK_RIGHT)
            facingLeft = false;
    }

    if (event.type == SDL_MOUSEBUTTONDOWN) {
        int mouseX = event.button.x;
        int mouseY = event.button.y;
        SDL_Point mousePoint = {mouseX, mouseY};

        if (!showDirection && !isPaused && !showPassScreen && !showGameOverScreen && SDL_PointInRect(&mousePoint, &pauseRect)) {
            isPaused = true;
        }
        else if (isPaused && SDL_PointInRect(&mousePoint, &continueRect)) {
            isPaused = false;
        }
        else if (isPaused && SDL_PointInRect(&mousePoint, &exitRect)) {
            running = false;
        }
        else if (!showDirection && !isPaused && !showPassScreen && !showGameOverScreen && SDL_PointInRect(&mousePoint, &directionButton)) {
            showDirection = true;
            currentPage = 1;
        }
        else if (showDirection) {
            if (SDL_PointInRect(&mousePoint, &nextRect) && currentPage == 1) currentPage = 2;
            if (SDL_PointInRect(&mousePoint, &backRect) && currentPage == 2) currentPage = 1;
            if (SDL_PointInRect(&mousePoint, &closeRect)) showDirection = false;
        }
        else if (showPassScreen) {
            if (SDL_PointInRect(&mousePoint, &menuRect)) {
                showPassScreen = false;
                showLevelPreview = true;
                loaded = false;
                completedLevels[level - 1] = true;
                lastPlantedFlower = plantedFlower;
                lastSeeds = seeds;
                if (level < 4) {
                    level++;
                }
            }
            else if (SDL_PointInRect(&mousePoint, &playAgainRect)) {
                showPassScreen = false;
                loaded = true; // Quay lại chơi ngay
                completedLevels[level - 1] = true;
                lastPlantedFlower = plantedFlower;
                lastSeeds = seeds;
                switch (level) {
                    case 1: lives = 5; seeds = 10; break;
                    case 2: lives = 5; seeds = 10; break;
                    case 3: lives = 4; seeds = 8; break;
                    case 4: lives = 4; seeds = 8; break;
                }
                plantedFlower = 0;
                bees.clear();
                plants.clear();
            }
            else if (SDL_PointInRect(&mousePoint, &passExitRect)) {
                completedLevels[level - 1] = true;
                lastPlantedFlower = plantedFlower;
                lastSeeds = seeds;
                running = false;
            }
        }
        else if (showGameOverScreen) {
            if (SDL_PointInRect(&mousePoint, &gameOverPlayAgainRect)) {
                showGameOverScreen = false;
                loaded = true; // Quay lại chơi ngay
                switch (level) {
                    case 1: lives = 5; seeds = 10; break;
                    case 2: lives = 5; seeds = 10; break;
                    case 3: lives = 4; seeds = 8; break;
                    case 4: lives = 4; seeds = 8; break;
                }
                plantedFlower = 0;
                bees.clear();
                plants.clear();
                inContactWithBee = false; // Reset trạng thái va chạm
                dizzyStartTime = 0;       // Reset thời gian chóng mặt
                isPaused = false;         // Đảm bảo không tạm dừng

            }
            else if (SDL_PointInRect(&mousePoint, &gameOverExitRect)) {
                running = false;
            }
        }
    }
}
