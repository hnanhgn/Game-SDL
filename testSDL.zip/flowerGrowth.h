#ifndef FLOWERGROWTH_H_INCLUDED
#define FLOWERGROWTH_H_INCLUDED

#include <SDL.h>

#include "definition.h"

void updateFlowerGrowth(std::vector<Plant>& plants);

#endif // FLOWERGROWTH_H_INCLUDED
