#ifndef BEEOPERATION_H_INCLUDED
#define BEEOPERATION_H_INCLUDED


void addBees(int level);
void moveBee( vector<Bee>& bees, vector<Plant>& plants);

#endif // BEEOPERATION_H_INCLUDED
